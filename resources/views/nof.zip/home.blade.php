@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>

                <div class="panel-body" align="center">
                
                                
                
                 <div style="margin:30px 0px 30px 0px "class="col-md-4"><i class="fa  fa-5x fa-pencil-square-o "></i> <br /> APPLY</div>
                 <div style="margin:30px 0px 30px 0px "class="col-md-4"><i class="fa  fa-5x fa-calendar "></i>          <br /> VIEW</div>
                 <div style="margin:30px 0px 30px 0px " class="col-md-4"><i class="fa  fa-5x fa-pencil-square-o "></i>  <br />  APPROVE</div>
                 
                 <div style="margin:30px 0px 30px 0px " class="col-md-4"><i class="fa  fa-5x fa-users "></i> <br />USER</div>
                 <div style="margin:30px 0px 30px 0px "  class="col-md-4"><i class="fa  fa-5x fa-calendar-o "></i> <br /> MANAGE</div>
                 <div style="margin:30px 0px 30px 0px " class="col-md-4"><i class="fa  fa-5x fa-cogs"></i> <br /> CONTROL</div>
                 
                 
               </div>
            </div>
        </div>
    </div>
</div>
@endsection
